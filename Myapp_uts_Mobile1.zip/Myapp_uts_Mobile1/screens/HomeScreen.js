import React from 'react';
// 1. Tambahkan Image pada import dari 'react-native'
import { View, Text, TouchableOpacity, StyleSheet, Image } from 'react-native';

export default function HomeScreen({ onLogout }) {
  return (
    <View style={styles.container}>
      <Text style={styles.header}>HOMEPAGE</Text>

      {/* Profil Card */}
      <View style={styles.profileCard}>
        {/* 2. Ganti View photoBox dengan komponen Image */}
        <Image 
          source={require('../assets/profile.png')} // sesuaikan nama & format file gambarmu
          style={styles.profileImage} 
        />
        <Text style={styles.nameText}>Banna Mahardika</Text>
        <Text style={styles.nameSubtitle}>NIM: 4112755201250087</Text>
        <Text style={styles.nameSubtitle}>Program Studi: Teknik Informatika</Text>
      </View>

      {/* Label Aktifitas */}
      <Text style={styles.sectionTitle}>Aktifitas</Text>

      {/* Grid Menu */}
      <View style={styles.gridContainer}>
        <View style={styles.row}>
          <TouchableOpacity style={styles.menuBox} activeOpacity={0.7}>
            <Text style={styles.menuTitle}>Tugas</Text>
            <Text style={styles.menuSubtitle}>0</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuBox} activeOpacity={0.7}>
            <Text style={styles.menuTitle}>Absensi</Text>
            <Text style={styles.menuSubtitle}>100%</Text>
          </TouchableOpacity>
        </View>

        <View style={styles.row}>
          <TouchableOpacity style={styles.menuBox} activeOpacity={0.7}>
            <Text style={styles.menuTitle}>Jadwal</Text>
            <Text style={styles.menuSubtitle}>7</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.menuBox} activeOpacity={0.7}>
            <Text style={styles.menuTitle}>Pengumuman</Text>
            <Text style={styles.menuSubtitle}>3</Text>
          </TouchableOpacity>
        </View>
      </View>

      {/* Tombol Logout */}
      <TouchableOpacity style={styles.logoutButton} onPress={onLogout} activeOpacity={0.8}>
        <Text style={styles.logoutText}>LOGOUT</Text>
      </TouchableOpacity>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    alignItems: 'center',
    backgroundColor: '#F3F4F6',
    paddingTop: 50,
    paddingHorizontal: 20,
  },
  header: {
    fontSize: 22,
    fontWeight: '800',
    color: '#1E293B',
    marginBottom: 20,
  },
  profileCard: {
    width: '100%',
    maxWidth: 380,
    backgroundColor: '#FFFFFF',
    borderRadius: 20,
    paddingVertical: 24,
    alignItems: 'center',
    marginBottom: 20,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.06,
    shadowRadius: 10,
    elevation: 3,
  },
  // 3. Tambahkan style khusus untuk Image
  profileImage: {
    width: 80,
    height: 80,
    borderRadius: 40, // Set Setengah dari width/height agar berbentuk lingkaran penuh
    marginBottom: 12,
  },
  nameText: {
    fontSize: 16,
    fontWeight: '700',
    color: '#0F172A',
  },
  sectionTitle: {
    width: '100%',
    maxWidth: 380,
    fontSize: 18,
    fontWeight: '700',
    color: '#1E293B',
    marginBottom: 12,
    paddingLeft: 4,
  },
  gridContainer: {
    width: '100%',
    maxWidth: 380,
    marginBottom: 20,
  },
  row: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: 12,
  },
  menuBox: {
    width: '48%',
    height: 80,
    backgroundColor: '#FFFFFF',
    borderRadius: 16,
    justifyContent: 'center',
    alignItems: 'center',
    paddingHorizontal: 8,
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.05,
    shadowRadius: 6,
    elevation: 2,
  },
  menuTitle: {
    fontSize: 13,
    fontWeight: '800',
    color: '#334155',
    marginBottom: 4,
  },
  menuSubtitle: {
    fontSize: 11,
    fontWeight: '600',
    color: '#64748B',
    textAlign: 'center',
  },
  logoutButton: {
    width: '100%',
    maxWidth: 380,
    height: 48,
    backgroundColor: '#FEF2F2',
    borderWidth: 1,
    borderColor: '#FCA5A5',
    borderRadius: 12,
    justifyContent: 'center',
    alignItems: 'center',
  },
  logoutText: {
    color: '#EF4444',
    fontSize: 14,
    fontWeight: '700',
  },
});